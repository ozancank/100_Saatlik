class Chat {
  String name;
  String message;
  String time;
  String avatarUrl;

  Chat({this.name, this.message, this.time, this.avatarUrl});
}

List<Chat> fakeData = [
    Chat(
        name: "Engin",
        message: "Merhaba nasılsın?",
        time: "13:30",
        avatarUrl:
            "https://yt3.ggpht.com/a-/AAuE7mCszIm7O2OG8iHuJT6Ln0z97uhny-Kkv1uqLA=s900-mo-c-c0xffffffff-rj-k-no"),
    Chat(
        name: "Derin",
        message: "Bugün napıyorsun?",
        time: "14:30",
        avatarUrl:
            "https://yt3.ggpht.com/a-/AAuE7mCszIm7O2OG8iHuJT6Ln0z97uhny-Kkv1uqLA=s900-mo-c-c0xffffffff-rj-k-no"),
    Chat(
        name: "Salih",
        message: "Eğitim bitti mi?",
        time: "15:30",
        avatarUrl:
            "https://yt3.ggpht.com/a-/AAuE7mCszIm7O2OG8iHuJT6Ln0z97uhny-Kkv1uqLA=s900-mo-c-c0xffffffff-rj-k-no"),
  ];
