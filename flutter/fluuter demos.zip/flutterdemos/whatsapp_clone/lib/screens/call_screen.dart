import 'package:flutter/material.dart';

class CallScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Aramalar", style: TextStyle(fontSize: 20)),
    );
  }
}
