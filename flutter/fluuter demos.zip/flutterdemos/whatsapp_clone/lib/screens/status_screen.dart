import 'package:flutter/material.dart';

class StatusScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Durumlar", style: TextStyle(fontSize: 20)),
    );
  }
}
